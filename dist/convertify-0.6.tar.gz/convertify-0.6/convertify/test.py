from convertify import Convertify
Convertify.convert('<your-path>')