from convertify import Convertify
x = Convertify()
x.convert('/Users/faton/Documents/python/image-convertify/images/')