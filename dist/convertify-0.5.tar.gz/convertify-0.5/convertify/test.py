from convertify import Convertify
Convertify.convert('/Users/faton/Documents/python/example-images')