from convertify import Convertify
x = Convertify()
x.convert('<your path here>')